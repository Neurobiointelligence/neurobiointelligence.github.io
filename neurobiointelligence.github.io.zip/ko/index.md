---
layout: default
title: 홈
lang: ko
---

<div class="hero" style="background-image: url('/images/VTA_DA.png'); height: 45vh;">
  <h1>홈</h1>
</div>

<section class="content-section">
<div class="container">
<p>
        We study the principles of Neurobiological Intelligence by investigating neural dynamics of cell types and circuits.
        Our lab integrates behavioral paradigms, imaging, optogenetics, molecular biology, and computational modeling to reveal
        how motivation, memory, and behavior interact at the circuit level.
      </p>
</div>
</section>
