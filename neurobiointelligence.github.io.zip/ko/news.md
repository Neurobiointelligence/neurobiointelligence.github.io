---
layout: default
title: 소식
lang: ko
---

<div class="hero" style="background-image: url('/images/chc_news.png'); height: 45vh;">
  <h1>소식</h1>
</div>

<section class="content-section">
<div class="container">
<h1>NEWS</h1>
<div class="news">
<h3>Sep 2025 – NeuroBiological Intelligence (NBI) Lab will open</h3>
<p>I am moving to GIST over the pacific ocean. Looking forward to it. </p>
</div>
</div>
</section>
