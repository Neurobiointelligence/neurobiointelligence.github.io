# KJung Lab @ GIST

Official homepage of the Neurobiological Intelligence Lab.

- Systems neuroscience, motivation, and behavior
- In vivo imaging, optogenetics, modeling
- Based at GIST (Gwangju Institute of Science and Technology)

Visit the site 👉 https://neurobiointelligence.github.io