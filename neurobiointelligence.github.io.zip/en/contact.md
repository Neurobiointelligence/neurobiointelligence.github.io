---
layout: default
title: Contact
lang: en
---

<div class="hero" style="background-image: url('/images/contact_gist_view.jpg'); height: 45vh;">
  <h1>Contact</h1>
</div>

<section class="content-section">
<main class="container">
<h1>CONTACT</h1>
<div class="contact-info">
<p><strong>KJung Lab @ GIST</strong></p>
<p>School of Life Sciences</p>
<p>Gwangju Institute of Science and Technology (GIST)</p>
<p>123 Cheomdangwagi-ro, Buk-gu, Gwangju 61005, Republic of Korea</p>
<p>광주과학기술원(GIST) 생명과학과 – KJung Lab for Neurobiological Intelligence</p>
<p>(61005) 광주광역시 북구 첨단과기로 123 </p>
<p>Email: <a href="mailto:kanghoon.jung@alleninstitute.org">kanghoon.jung@alleninstitute.org</a></p>
</div>
<iframe src="https://www.google.com/maps?q=gist%20south%20korea&amp;output=embed"></iframe>
</main>
</section>
