---
layout: default
title: Members
lang: en
---

<div class="hero" style="background-image: url('/images/Mesolimbic.png'); height: 45vh;">
  <h1>Members</h1>
</div>

<section class="content-section">
<div class="container">
<h1>MEMBERS</h1>
<div class="member-entry">
<h2>KANGHOON JUNG</h2>
<div class="member-profile">
<img alt="Dr. Kanghoon Jung" src="\_members/KanghoonJ_photo.jpg"/>
<div class="member-info">
<p>Principal Investigator</p>
<p>
<a href="_members/minibio_kj.html">[minibio]</a>
<a href="https://scholar.google.com/citations?user=EXAMPLE" target="_blank">[Google Scholar]</a>
</p>
<p><a href="mailto:kanghoon.jung@alleninstitute.org">kanghoon.jung@alleninstitute.org</a></p>
</div>
</div>
</div>
<!-- Add more members here -->
</div>
</section>
