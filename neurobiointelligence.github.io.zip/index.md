---
layout: default
title: Welcome
---

<div style="text-align: center; padding: 60px;">
  <h1>Welcome to KJung Lab</h1>
  <p>Please select your preferred language</p>
  <a href="/en/" style="margin: 20px; font-size: 1.2rem;">🇺🇸 English</a>
  <a href="/ko/" style="margin: 20px; font-size: 1.2rem;">🇰🇷 한국어</a>
</div>
